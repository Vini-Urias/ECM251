# Fernando Henriques Neto
# RA:18.00931-0

from enum import Enum
class Paginas(Enum):
    LOGIN    = 1
    CADASTRO = 2
    HOME     = 3

class Platafromas(Enum):
    PS3     = 1
    XBOX360 = 2
    PS4     = 3
    XBOXONE = 4
    PC      = 5